﻿app.controller("SuperAdminController", function ($scope, $http) {
    $scope.model = {};
    $scope.Detmodel = {};
    $scope.model.txtSearch = "";
    $scope.model.IsEdit = false;
    $scope.GroupId = "";
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.GroupSearch = function () {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "Group/GetUsers",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    return opt;
                },
            },
            schema:
            {
                model:
                {
                    id: "Id",
                    fields: {

                    }
                }
            },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,
      
    //     toolbar: [
    //    {
    //        template: "<a href='javascript:void(0);' class='btn btn-primary-o btn-sm' id='actionButton'     ng-click='OpenImportPopup(this)'  data-container='body' title='Add'>Import CSV</a>"
    //    }
    //],  
        columns: [
            {
                field: "Name",
                title: "Employee",
                width: "80px",
                filterable: false,

            },
            {
                field: "code",
                title: "Code",
                width: "80px",
                filterable: false,

            },
            {
                field: "SuperAdminString",
                title: "Is SuperAdmin?",
                width: "80px",
                filterable: false,
            },
            {
                field: "WebLoginString",
                title: "Can login to portal?",
                width: "80px",
                filterable: false,
            },
           
            {
              

                template: "#  if (SuperAdminString == 'Yes' ) { # <a href='javascript:void(0);' ng-click='changeStatus(this)'  data-toggle='tooltip' title='Remove Super Admin' <i class='las la-times-circle text-danger'></i> </a> #} \
                  else if (SuperAdminString == 'No' ) { # <a href='javascript:void(0);' ng-click='changeStatus(this)'  data-toggle='tooltip' title='Make Super Admin' <i class='las la-info-circle'></i> </a> #}\
                 if (WebLoginString == 'Yes' ) { # <a href='javascript:void(0);' ng-click='changeLoginStatus(this)'  data-toggle='tooltip' title='Remove Web access' <i class='las la-times-circle text-danger'></i> </a> #} \
                  else if (WebLoginString == 'No' ) { # <a href='javascript:void(0);' ng-click='changeLoginStatus(this)'  data-toggle='tooltip' title='Give Web access' <i class='las la-info-circle'></i> </a> #} \#",                  
                width: "40px",
                title: "Action",
                headerAttributes: { style: "text-align:center;" },
                attributes: { style: "text-align:center;" },

            },

        ]
    };
   

    $scope.changeStatus = function (obj) {
        debugger;
        var currentAccess = "";
        if (obj.dataItem.SuperAdminString=="Yes")
            currentAccess = "remove";
        else
            currentAccess = "give";
        var warnText = "Are you sure you want to " + currentAccess+ " Super Admin access?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $http({
                    method: 'GET',
                    url: baseUrl + 'Group/ChangeSuperAdmin?Id=' + obj.dataItem.Id + "&IsAdmin=" + obj.dataItem.SuperAdminString,

                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Update');                   
                    $("#mainGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });


    }


    $scope.changeLoginStatus = function (obj) {
        debugger;
        var currentAccess = "";
        if (obj.dataItem.WebLoginString == "Yes")
            currentAccess = "remove";
        else
            currentAccess = "give";
        var warnText = "Are you sure you want to " + currentAccess + " Web login access?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $http({
                    method: 'GET',
                    url: baseUrl + 'Group/ChangeWebLoginAccess?Id=' + obj.dataItem.Id + "&IsAdmin=" + obj.dataItem.WebLoginString,

                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Update');
                    $("#mainGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });


    }


    $scope.OpenImportPopup = function (e) {
        debugger;
        $("#file").val("");
      
        $scope.winOptions = {
            title: "Import",
        }
        $scope.ImportPopup.setOptions($scope.winOptions);
        $scope.ImportPopup.open().center();


    }


    $scope.CancelImport = function (e) {
        $scope.ImportPopup.close();
    }



    $scope.getFileDetails = function (e) {
        debugger;
        $scope.files = [];
        $scope.$apply(function () {

            // STORE THE FILE OBJECT IN AN ARRAY.
            for (var i = 0; i < e.files.length; i++) {
                $scope.files.push(e.files[i])
            }

        });
    };

    $scope.uploadFiles = function () {
        debugger;
        showloader();
        //FILL FormData WITH FILE DETAILS.
        var data = new FormData();

        for (var i in $scope.files) {
            data.append("uploadedFile", $scope.files[i]);
        }

        // ADD LISTENERS.
        var objXhr = new XMLHttpRequest();

        objXhr.onreadystatechange = function () {
            debugger
            // var res =  XMLHttpRequest.responseText;

            if (this.readyState == 4 && this.status == 200) {
                hideloader();

                if (objXhr.responseText == "uploaded") {
                    WarnMessage("CSV uploaded successfully.");
                    $("#childGrid").data("kendoGrid").dataSource.read();
                }
                else if (objXhr.responseText == "invalid") {
                    WarnMessage("Some of the records have been imported and some were trauncated because of invalid branch codes");
                    $("#childGrid").data("kendoGrid").dataSource.read();
                }
                else if (objXhr.responseText == "nofile")
                    WarnMessage("Please upload a CSV file");
                else if (objXhr.responseText == "invalidFormat")
                    WarnMessage("Invalid file format");
                else if (objXhr.responseText == "duplicate")
                    WarnMessage("All these records already exists");
                else if (objXhr.responseText == "notupl")
                    WarnMessage("Invalid Branch codes");

                else
                    WarnMessage("CSV upload failed !!");

            }
        };


        objXhr.open("POST", baseUrl + '/Group/ImportUser');
        objXhr.setRequestHeader('GroupId', $scope.GroupId);

        objXhr.send(data);
    }

});